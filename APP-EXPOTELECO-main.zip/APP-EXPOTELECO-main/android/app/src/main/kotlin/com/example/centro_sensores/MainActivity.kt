package com.example.centro_sensores

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

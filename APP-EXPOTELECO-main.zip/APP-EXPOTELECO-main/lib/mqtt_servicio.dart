import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'dart:convert';
import 'constantes.dart';

MqttServerClient? cliente;
bool conectado = false;
Function(Map<String, dynamic>)? alRecibirDatos;
Function(bool)? alCambiarConexion;

Future<void> conectarMqtt() async {
  String id = 'flutter_' + DateTime.now().millisecondsSinceEpoch.toString();
  cliente = MqttServerClient(Constantes.mqttBroker, id);
  cliente!.port = Constantes.mqttPuerto;
  cliente!.secure = true;
  cliente!.keepAlivePeriod = 60;
  cliente!.setProtocolV311();
  cliente!.logging(on: false);
  cliente!.onConnected = () {
    conectado = true;
    if (alCambiarConexion != null) alCambiarConexion!(true);
  };
  cliente!.onDisconnected = () {
    conectado = false;
    if (alCambiarConexion != null) alCambiarConexion!(false);
    reintentar();
  };

  try {
    await cliente!.connect(Constantes.mqttUsuario, Constantes.mqttClave);
  } catch (e) {
    reintentar();
    return;
  }

  if (cliente!.connectionStatus!.state == MqttConnectionState.connected) {
    cliente!.subscribe(Constantes.mqttTopic, MqttQos.atLeastOnce);
    cliente!.updates!.listen((mensajes) {
      for (var m in mensajes) {
        MqttPublishMessage msg = m.payload as MqttPublishMessage;
        String texto = MqttPublishPayload.bytesToStringAsString(msg.payload.message);
        try {
          if (alRecibirDatos != null) alRecibirDatos!(jsonDecode(texto));
        } catch (e) {
          print('error JSON');
        }
      }
    });
  } else {
    reintentar();
  }
}

void reintentar() {
  Future.delayed(Duration(seconds: 5), () {
    if (!conectado) conectarMqtt();
  });
}

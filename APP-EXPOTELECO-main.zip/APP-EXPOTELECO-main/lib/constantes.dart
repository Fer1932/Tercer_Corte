//credenciales mqtt y hivemq
class Constantes {
  static const String mqttBroker  = 'f33470037ad74a3891ca58f72dffc77a.s1.eu.hivemq.cloud';
  static const int    mqttPuerto  = 8883;
  static const String mqttUsuario = 'expoteleco';
  static const String mqttClave   = 'Expoteleco2026';
  static const String mqttTopic   = 'expoteleco/device01/sensores';

  //credenciales supabase
  static const String supabaseUrl   = 'https://agdsspomcjqgrkofdpgg.supabase.co';
  static const String supabaseClave = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFnZHNzcG9tY2pxZ3Jrb2ZkcGdnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg2MzYwOTQsImV4cCI6MjA5NDIxMjA5NH0.5LWZDeOM039s6Ytq3Xk_dH_Sy0YlHc8Wvsym4-WaKDE';
}

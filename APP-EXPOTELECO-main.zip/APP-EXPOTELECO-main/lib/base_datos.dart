import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

Future<Database> abrirBase() async {
  String ruta = join(await getDatabasesPath(), 'sensores.db');
  return await openDatabase(ruta, version: 1, onCreate: (db, v) async {
    await db.execute('''
      CREATE TABLE lecturas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        temperatura REAL,
        humedad REAL,
        buzzerClima INTEGER,
        distancia REAL,
        ledVerde INTEGER,
        ledAmarillo INTEGER,
        ledRojo INTEGER,
        buzzerMovimiento INTEGER
      )
    ''');
  });
}

Future<void> guardarLectura(Map<String, dynamic> datos) async {
  Database db = await abrirBase();
  await db.insert('lecturas', datos);
  await db.close();
}

Future<List<Map<String, dynamic>>> obtenerLecturas() async {
  Database db = await abrirBase();
  var resultado = await db.query('lecturas', orderBy: 'timestamp DESC', limit: 50);
  await db.close();
  return resultado;
}

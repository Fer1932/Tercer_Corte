import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:intl/intl.dart';
import 'mqtt_servicio.dart';
import 'base_datos.dart';

class PantallaPrincipal extends StatefulWidget {
  @override
  State<PantallaPrincipal> createState() => _PantallaPrincipalState();
}

class _PantallaPrincipalState extends State<PantallaPrincipal> {

  double temperatura = 0;
  double humedad = 0;
  bool buzzerClima = false;
  double distancia = 0;
  bool ledVerde = false;
  bool ledAmarillo = false;
  bool ledRojo = false;
  bool buzzerMovimiento = false;

  int pagina = 0;
  bool mqttConectado = false;
  List<Map<String, dynamic>> historial = [];

  Color fondo = Color(0xFF16213E);

  @override
  void initState() {
    super.initState();
    alCambiarConexion = (estado) => setState(() => mqttConectado = estado);
    alRecibirDatos = recibirDatos;
    cargarHistorial();
  }

  void recibirDatos(Map<String, dynamic> d) {
    setState(() {
      temperatura = d['temperatura'].toDouble();
      humedad = d['humedad'].toDouble();
      buzzerClima = d['buzzerDht'] == 1;
      distancia = d['distancia'].toDouble();
      ledVerde = d['ledVerde'] == 1;
      ledAmarillo = d['ledAmarillo'] == 1;
      ledRojo = d['ledRojo'] == 1;
      buzzerMovimiento = d['buzzer'] == 1;
    });
    guardar();
  }

  void guardar() async {
    Map<String, dynamic> r = {
      'timestamp': DateTime.now().toIso8601String(),
      'temperatura': temperatura,
      'humedad': humedad,
      'buzzerClima': buzzerClima ? 1 : 0,
      'distancia': distancia,
      'ledVerde': ledVerde ? 1 : 0,
      'ledAmarillo': ledAmarillo ? 1 : 0,
      'ledRojo': ledRojo ? 1 : 0,
      'buzzerMovimiento': buzzerMovimiento ? 1 : 0,
    };
    await guardarLectura(r);
    try {
      await Supabase.instance.client.from('lecturas').insert(r);
    } catch (e) {
      print('sin internet');
    }
    cargarHistorial();
  }

  void cargarHistorial() async {
    try {
      var d = await Supabase.instance.client.from('lecturas')
          .select().order('timestamp', ascending: false).limit(50);
      setState(() => historial = List<Map<String, dynamic>>.from(d));
    } catch (e) {
      var d = await obtenerLecturas();
      setState(() => historial = d);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: fondo,
        centerTitle: true,
        title: Text('CENTRO DE SENSORES',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        actions: [indicador()],
      ),
      body: pagina == 0 ? pantallaSensores() : pantallaHistorial(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: pagina,
        backgroundColor: fondo,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.grey,
        onTap: (i) => setState(() => pagina = i),
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.sensors), label: 'Sensores'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'Historial'),
        ],
      ),
    );
  }

  Widget indicador() {
    Color c = mqttConectado ? Colors.greenAccent : Colors.red;
    String t = mqttConectado ? 'Conectado' : 'Sin senal';
    return Padding(
      padding: EdgeInsets.only(right: 14),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 10, height: 10,
            decoration: BoxDecoration(shape: BoxShape.circle, color: c)),
        SizedBox(width: 5),
        Text(t, style: TextStyle(color: c, fontSize: 11)),
      ]),
    );
  }

  Widget pantallaSensores() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(children: [
        tarjetaClima(),
        SizedBox(height: 16),
        tarjetaMovimiento(),
        SizedBox(height: 16),
        tarjetaIntegrantes(),
      ]),
    );
  }

  Widget tarjetaClima() {
    return tarjeta('CLIMA  (DHT22)', Column(children: [
      filaDato('Temperatura', temperatura.toStringAsFixed(1) + ' °C'),
      filaDato('Humedad', humedad.toStringAsFixed(1) + ' %'),
      Divider(color: Colors.white24, height: 24),
      textoBuzzer(buzzerClima),
    ]));
  }

  Widget tarjetaMovimiento() {
    return tarjeta('MOVIMIENTO  (Ultrasonico)', Column(children: [
      filaDato('Distancia', distancia.toStringAsFixed(0) + ' cm'),
      Divider(color: Colors.white24, height: 24),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        led('VERDE', ledVerde, Colors.green),
        led('AMARILLO', ledAmarillo, Colors.orange),
        led('ROJO', ledRojo, Colors.red),
      ]),
      SizedBox(height: 12),
      textoBuzzer(buzzerMovimiento),
    ]));
  }

  Widget tarjetaIntegrantes() {
    var nombres = ['Juan Figueroa', 'Nicole Pachon', 'Paula Caballero',
                   'Shirley Yepez', 'Fernando Ayala'];
    return tarjeta('INTEGRANTES', Column(
      children: nombres.map((n) => Padding(
        padding: EdgeInsets.symmetric(vertical: 4),
        child: Text(n, style: TextStyle(color: Colors.white70)),
      )).toList(),
    ));
  }

  Widget pantallaHistorial() {
    if (historial.isEmpty) {
      return Center(child: Text('Sin datos aun', style: TextStyle(color: Colors.grey)));
    }
    return ListView.builder(
      padding: EdgeInsets.all(12),
      itemCount: historial.length,
      itemBuilder: (_, i) => itemHistorial(historial[i]),
    );
  }

  Widget itemHistorial(Map l) {
    String fecha = DateFormat('yyyy-MM-dd  HH:mm:ss')
        .format(DateTime.parse(l['timestamp']));
    String bc = l['buzzerClima'] == 1 ? 'ACTIVADO' : 'APAGADO';
    String bm = l['buzzerMovimiento'] == 1 ? 'ACTIVADO' : 'APAGADO';
    String v = l['ledVerde'] == 1 ? 'Verde ' : '';
    String a = l['ledAmarillo'] == 1 ? 'Amarillo ' : '';
    String r = l['ledRojo'] == 1 ? 'Rojo ' : '';

    return Card(
      color: fondo,
      margin: EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(fecha, style: TextStyle(color: Colors.cyan, fontSize: 11)),
          SizedBox(height: 6),
          Text('CLIMA', style: TextStyle(color: Colors.lightBlueAccent,
              fontSize: 11, fontWeight: FontWeight.bold)),
          textoBlanco('Temp: ' + l['temperatura'].toString() + ' °C    Hum: '
              + l['humedad'].toString() + ' %'),
          textoBlanco('Buzzer: ' + bc),
          SizedBox(height: 6),
          Text('MOVIMIENTO', style: TextStyle(color: Colors.orangeAccent,
              fontSize: 11, fontWeight: FontWeight.bold)),
          textoBlanco('Distancia: ' + l['distancia'].toString() + ' cm'),
          Row(children: [
            Text('LEDs: ', style: TextStyle(color: Colors.white, fontSize: 12)),
            Text(v, style: TextStyle(color: Colors.green, fontSize: 12,
                fontWeight: FontWeight.bold)),
            Text(a, style: TextStyle(color: Colors.orange, fontSize: 12,
                fontWeight: FontWeight.bold)),
            Text(r, style: TextStyle(color: Colors.red, fontSize: 12,
                fontWeight: FontWeight.bold)),
          ]),
          textoBlanco('Buzzer: ' + bm),
        ]),
      ),
    );
  }

  Widget textoBlanco(String t) =>
      Text(t, style: TextStyle(color: Colors.white, fontSize: 12));

  Widget textoBuzzer(bool activo) {
    String t = activo ? 'ACTIVADO' : 'APAGADO';
    Color c = activo ? Colors.yellow : Colors.grey;
    return Text('BUZZER: ' + t,
        style: TextStyle(color: c, fontWeight: FontWeight.bold));
  }

  Widget tarjeta(String titulo, Widget hijo) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(color: fondo,
          borderRadius: BorderRadius.circular(15)),
      child: Column(children: [
        Text(titulo, style: TextStyle(fontSize: 17,
            fontWeight: FontWeight.bold, color: Colors.white)),
        SizedBox(height: 16),
        hijo,
      ]),
    );
  }

  Widget filaDato(String etiqueta, String valor) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(etiqueta, style: TextStyle(color: Colors.white70)),
        Text(valor, style: TextStyle(color: Colors.white,
            fontSize: 16, fontWeight: FontWeight.bold)),
      ]),
    );
  }

  Widget led(String nombre, bool on, Color color) {
    return Column(children: [
      Container(width: 44, height: 44,
          decoration: BoxDecoration(shape: BoxShape.circle,
              color: on ? color : Color(0xFF444444))),
      SizedBox(height: 4),
      Text(nombre, style: TextStyle(color: Colors.white70, fontSize: 11)),
    ]);
  }
}

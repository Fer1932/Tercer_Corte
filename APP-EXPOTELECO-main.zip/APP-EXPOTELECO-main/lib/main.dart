import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'constantes.dart';
import 'mqtt_servicio.dart';
import 'pantalla_principal.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // iniciar supabase
  await Supabase.initialize(
    url: Constantes.supabaseUrl,
    anonKey: Constantes.supabaseClave,
  );

  // conectar al broker mqtt
  conectarMqtt();

  runApp(MiApp());
}

class MiApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Centro de Sensores',
      debugShowCheckedModeBanner: false,
      home: PantallaPrincipal(),
    );
  }
}
